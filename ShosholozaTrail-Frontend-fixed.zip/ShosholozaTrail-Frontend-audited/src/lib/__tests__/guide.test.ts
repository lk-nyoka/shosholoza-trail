/**
 * What the route guide will and will not say.
 *
 * This is a retrieval system, not a language model, and its failure mode is
 * specific: TF-IDF always has a best match, so without a floor it answers a
 * question about safety with whichever tourism document happens to share a
 * word. On a product about physical travel that is the failure that matters,
 * and it is not visible by reading the code — only by asking.
 *
 * The two bands below were measured, not guessed. If the corpus changes,
 * re-measure: questions the guide covers must stay above ANSWER_FLOOR and
 * questions it does not must stay below it.
 */
import { answer, query, CORPUS } from "../aiEngine";

let failures = 0;
function check(name: string, ok: boolean, detail = ""): void {
  if (!ok) failures += 1;
  console.log(`${ok ? "pass" : "FAIL"}  ${name}${ok || !detail ? "" : `  (${detail})`}`);
}
const has = (q: string, fragment: string) => {
  const a = answer(q);
  check(`"${q}" → ${fragment}`, a.toLowerCase().includes(fragment.toLowerCase()), a.slice(0, 90));
};
const fallsBack = (q: string) => {
  const a = answer(q);
  check(`"${q.slice(0, 34)}" → honest fallback`, a.startsWith("I can answer questions about"), a.slice(0, 90));
};

check("corpus loaded", CORPUS.length >= 30, `${CORPUS.length} docs`);

// ── Safety-critical intents are never answered from the tourism corpus ──────
has("Is the train safe at night?", "can't advise on safety");
has("Is this station dangerous?", "can't advise on safety");
has("is the train delayed", "don't have live running information");
has("which platform does it leave from", "don't have live running information");
has("there has been an accident, call an ambulance", "10111");
has("how do I book a ticket", "can't book or pay for a train ticket");
has("can I get a refund", "can't book or pay for a train ticket");

// ── The ticket guard must not swallow the page's own suggested questions ────
has("Can I book a room at Lord Milner Hotel?", "Lord Milner");
has("book a table at the coffee house", "Coffee House");
has("Best place to buy crafts in Johannesburg?", "Rosebank");

// ── Questions the guide genuinely covers ────────────────────────────────────
has("What is ShosholozaTrail?", "travel companion");
has("Help me choose a mode.", "Adventure");
has("What is the next stop?", "does not know where the train is");
has("Tell me about Kimberley", "Kimberley");
has("the Big Hole", "Big Hole");
has("how long is the journey", "1 568 km");
has("does it work offline", "offline");

// ── Questions it does not cover are refused, not approximated ───────────────
fallsBack("asdkjh qwe zxcvb");
fallsBack("SELECT * FROM users; DROP TABLE stops;--");
fallsBack("what is the weather tomorrow");
fallsBack("can I bring my dog");
fallsBack("");
fallsBack("   ");
fallsBack("a".repeat(4000));

// ── It never throws, whatever it is handed ──────────────────────────────────
for (const nasty of ["<script>alert(1)</script>", "\u0000\u0001", "🚂".repeat(500), "?".repeat(2000)]) {
  let threw = false;
  try { answer(nasty); query(nasty); } catch { threw = true; }
  check(`survives ${JSON.stringify(nasty.slice(0, 16))}`, !threw);
}

console.log(failures ? `\n${failures} FAILED` : "\nall passed");
// Thrown rather than process.exit so this file needs no Node types: an uncaught
// error still leaves a non-zero exit code for the runner and for CI.
if (failures) throw new Error(`${failures} assertion(s) failed`);
