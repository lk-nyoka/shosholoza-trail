/**
 * The building-versus-railway test.
 *
 * The case that matters is the one corner-testing cannot see: a footprint whose
 * every corner is comfortably clear of the line while the line runs through its
 * middle. Park Station is mapped that way - one polygon over its own platforms -
 * and extruded it became a solid block with the train inside it.
 *
 *   npx esbuild src/lib/__tests__/corridor.test.ts --bundle --platform=node \
 *     --format=cjs --outfile=/tmp/t.cjs && node /tmp/t.cjs
 */
import { ringIntersectsCorridor, segmentDistanceSq } from "../railWorld";

let failures = 0;
const check = (name: string, actual: unknown, expected: unknown) => {
  const ok = Math.abs(Number(actual) - Number(expected)) < 1e-6 || actual === expected;
  if (!ok) failures += 1;
  console.log(`${ok ? "pass" : "FAIL"}  ${name}${ok ? "" : `  (got ${actual}, wanted ${expected})`}`);
};

// A line of track running west to east through z = 0.
const straightTrack = Array.from({ length: 41 }, (_, i) => ({ x: -200 + i * 10, z: 0 }));

// ── segmentDistanceSq ───────────────────────────────────────────────────────
check("crossing segments are zero apart", segmentDistanceSq(-5, 0, 5, 0, 0, -5, 0, 5), 0);
check("parallel segments 5 m apart", segmentDistanceSq(0, 5, 10, 5, 0, 0, 10, 0), 25);
check("collinear but disjoint", segmentDistanceSq(0, 0, 10, 0, 20, 0, 30, 0), 100);

// ── the Park Station case ───────────────────────────────────────────────────
// 300 m x 120 m, straddling the line. Every corner is 60 m from the rails -
// well outside the 17 m clearance - and the track runs right through it.
const station = [-150, -60,  150, -60,  150, 60,  -150, 60];
check("track through the middle is caught", ringIntersectsCorridor(station, straightTrack, 17), true);

// The old corner test on the same polygon: all four corners are 60 m away.
const cornersOnly = [-150, -60, 150, -60, 150, 60, -150, 60]
  .reduce<number[][]>((acc, v, i) => (i % 2 ? (acc[acc.length - 1].push(v), acc) : [...acc, [v]]), [])
  .map(([x, z]) => Math.min(...straightTrack.map(t => Math.hypot(t.x - x, t.z - z))));
check("...and every corner really was clear", Math.min(...cornersOnly) > 17, true);

// ── a wall running parallel, endpoints far from any sample ──────────────────
const wall = [-500, 8, -480, 8, -480, 30, -500, 30];
const shortTrack = [{ x: -495, z: 0 }, { x: -485, z: 0 }];
check("parallel wall 8 m from the rails is caught", ringIntersectsCorridor(wall, shortTrack, 17), true);

// ── a building that genuinely is clear ──────────────────────────────────────
const house = [40, 60, 60, 60, 60, 80, 40, 80];
check("a house 60 m away is left alone", ringIntersectsCorridor(house, straightTrack, 17), false);

// ── nothing near at all: the cheap path ─────────────────────────────────────
const faraway = [5000, 5000, 5020, 5000, 5020, 5020, 5000, 5020];
check("open country costs one bounding box", ringIntersectsCorridor(faraway, straightTrack, 17), false);

// ── just outside vs just inside the clearance ───────────────────────────────
check("18 m away is clear", ringIntersectsCorridor([0, 18, 10, 18, 10, 40, 0, 40], straightTrack, 17), false);
check("16 m away is not", ringIntersectsCorridor([0, 16, 10, 16, 10, 40, 0, 40], straightTrack, 17), true);

console.log(failures ? `\n${failures} FAILED` : "\nall passed");
// Node only; the app never imports this file.
declare const process: { exit(code: number): never };
process.exit(failures ? 1 : 0);
