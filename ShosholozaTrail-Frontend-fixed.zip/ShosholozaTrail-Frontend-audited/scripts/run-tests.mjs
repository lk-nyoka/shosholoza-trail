/**
 * The project's test runner.
 *
 * These suites are plain TypeScript with no test framework: esbuild bundles
 * each one for Node and runs it. A suite prints one line per assertion and
 * exits non-zero if any failed, so CI, Netlify or a person at a terminal all
 * get the same answer. Adding a suite means adding a file below.
 */
import { execFileSync } from "node:child_process";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const SUITES = [
  ["corridor", "src/lib/__tests__/corridor.test.ts"],
  ["storage",  "src/lib/__tests__/storage.test.ts"],
  ["guide",    "src/lib/__tests__/guide.test.ts"],
];

const out = mkdtempSync(join(tmpdir(), "st-tests-"));
let failed = 0;

for (const [name, entry] of SUITES) {
  const bundle = join(out, `${name}.mjs`);
  console.log(`\n── ${name} ${"─".repeat(Math.max(0, 60 - name.length))}`);
  try {
    execFileSync("npx", ["esbuild", entry, "--bundle", "--platform=node",
      "--format=esm", `--outfile=${bundle}`, "--log-level=error"], { stdio: "inherit" });
    execFileSync(process.execPath, [bundle], { stdio: "inherit" });
  } catch {
    failed += 1;
  }
}

console.log(failed ? `\n${failed} suite(s) failed` : "\nall suites passed");
process.exit(failed ? 1 : 0);
