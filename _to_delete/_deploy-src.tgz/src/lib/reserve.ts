/**
 * Reserve-and-collect.
 *
 * The app does not take payment. On this corridor the vendors are small — a
 * padstal, a platform café, a craft table — and asking them to onboard to a
 * payout system before a single passenger has bought anything is how a pilot
 * dies. So the passenger reserves, the vendor decides whether to prepare it,
 * and money changes hands in person the way it already does.
 *
 * The collection code is the point. It is what turns "someone said they'd come"
 * into a transaction both sides can verify, which is the thing a commission has
 * to be charged against. It is also what protects the vendor: nothing is
 * prepared until they accept, and an unclaimed code simply expires.
 *
 * Reservations are held on the passenger's device in this build. Vendor
 * acceptance needs a service neither side has yet, so the vendor's half is
 * shown as a demonstration and labelled as one.
 */

export type ReservationState = "requested" | "accepted" | "declined" | "collected" | "expired";

export interface Reservation {
  id: string;
  placeId: string;
  placeName: string;
  stopId: string;
  stopName: string;
  code: string;
  state: ReservationState;
  requestedAt: number;
  note?: string;
}

const KEY = "st.reservations.v1";

/**
 * Short, readable over the noise of a station, and unambiguous when spoken:
 * no letters that sound alike and no digits that look like letters.
 */
const ALPHABET = "ACDEFHJKLMNPRTVWXY349";

function makeCode(): string {
  const bytes = new Uint8Array(4);
  crypto.getRandomValues(bytes);
  const body = Array.from(bytes, b => ALPHABET[b % ALPHABET.length]).join("");
  return `SZ-${body}`;
}

function readAll(): Reservation[] {
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Reservation[]) : [];
  } catch {
    return [];
  }
}

function writeAll(list: Reservation[]): void {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    /* best effort */
  }
}

export function reservations(): Reservation[] {
  return readAll().sort((a, b) => b.requestedAt - a.requestedAt);
}

export function reservationFor(placeId: string): Reservation | null {
  return readAll().find(r => r.placeId === placeId && r.state !== "expired" && r.state !== "declined") ?? null;
}

export function requestReservation(input: {
  placeId: string; placeName: string; stopId: string; stopName: string; note?: string;
}): Reservation {
  const reservation: Reservation = {
    id: `${input.placeId}-${Date.now()}`,
    code: makeCode(),
    state: "requested",
    requestedAt: Date.now(),
    ...input,
  };
  writeAll([...readAll().filter(r => r.placeId !== input.placeId), reservation]);
  return reservation;
}

export function setReservationState(id: string, state: ReservationState): void {
  writeAll(readAll().map(r => (r.id === id ? { ...r, state } : r)));
}

export function cancelReservation(id: string): void {
  writeAll(readAll().filter(r => r.id !== id));
}

export const STATE_LABEL: Record<ReservationState, string> = {
  requested: "Waiting for the vendor",
  accepted:  "Confirmed — collect with your code",
  declined:  "Vendor could not take it",
  collected: "Collected",
  expired:   "Expired",
};
