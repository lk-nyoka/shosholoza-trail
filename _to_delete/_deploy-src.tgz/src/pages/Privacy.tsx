import { useState } from "react";
import { Link } from "react-router-dom";
import { clearLocationConsent, locationConsent } from "../lib/consent";
import "./Privacy.css";

/**
 * The POPIA notice.
 *
 * Written to describe what this build actually does, not what the architecture
 * plans to do. Every line here is checkable against the code: if a claim on
 * this page stops being true, the page is wrong and must change with it.
 */
export default function Privacy() {
  const [consent, setConsent] = useState(locationConsent());

  const withdraw = () => {
    clearLocationConsent();
    setConsent(locationConsent());
  };

  return (
    <div className="privacy-page">
      <div className="container">
        <header className="section privacy-header">
          <p className="t-eyebrow">Privacy</p>
          <h1 className="t-display t-display--lg privacy-header__heading">
            What we collect,<br />and what we don't.
          </h1>
          <p className="t-body privacy-header__sub">
            Shosholoza Trail is designed to work with as little of your data as possible.
            This notice describes the current build, in line with the Protection of
            Personal Information Act.
          </p>
        </header>

        <section className="privacy-section" aria-labelledby="location">
          <h2 id="location" className="t-heading t-heading--lg">Your location</h2>
          <p>
            The app asks before it reads your position, and only reads it while you have
            the live journey open. Your position is used on your own device to place you
            on the route, estimate arrival times and show what is near you.
          </p>
          <p>
            We do not keep a location history, we do not show your position to other
            passengers, and we do not sell or share it.
          </p>
          <p>
            If you tap <b>I'm at this point</b>, one position reading is sent to our
            journey service so the app can estimate how fast the train is actually
            moving. It is attached to a random identifier generated in your browser,
            not to you, and it is not linked to any other reading.
          </p>
          <div className="privacy-control">
            <div>
              <b>Location permission on this device</b>
              <span>
                {consent === "granted" ? "You have allowed location use."
                  : consent === "declined" ? "You have declined location use."
                  : "You have not been asked yet."}
              </span>
            </div>
            <button className="btn btn--outline btn--sm" onClick={withdraw} disabled={consent === "unasked"}>
              Withdraw permission
            </button>
          </div>
          <p className="privacy-note">
            Withdrawing here clears your answer in this app. Your browser keeps its own
            site permission separately — you can reset that in your browser's site settings.
          </p>
        </section>

        <section className="privacy-section" aria-labelledby="accounts">
          <h2 id="accounts" className="t-heading t-heading--lg">Accounts and saved items</h2>
          <p>
            There are no accounts in this build. Nothing asks for your name, phone number
            or email address. Places you save stay in your browser's storage on this
            device and are not sent anywhere.
          </p>
        </section>

        <section className="privacy-section" aria-labelledby="third-parties">
          <h2 id="third-parties" className="t-heading t-heading--lg">Who else sees a request</h2>
          <p>
            The journey draws satellite imagery, elevation and map data, and photographs
            from outside services. Loading them means those services receive your IP
            address and the area of the map you are looking at, the same as any website
            that shows a map. They do not receive your GPS position, and we send them no
            information about you.
          </p>
          <p>
            The <Link to="/credits">credits page</Link> lists each data and imagery source.
          </p>
        </section>

        <section className="privacy-section" aria-labelledby="offline">
          <h2 id="offline" className="t-heading t-heading--lg">Offline copies</h2>
          <p>
            The app stores the journey on your device so it keeps working without signal.
            That cache holds route, place and story data — no personal information. Clearing
            the site's data in your browser removes it.
          </p>
        </section>

        <section className="privacy-section" aria-labelledby="rights">
          <h2 id="rights" className="t-heading t-heading--lg">Your rights</h2>
          <p>
            Under POPIA you may ask what personal information we hold about you, ask us to
            correct or delete it, and object to how it is used. Because this build keeps
            your data on your own device, clearing the site's data removes it. For the
            position readings sent with <b>I'm at this point</b>, tell us the session
            identifier shown on the live journey screen and we will delete those readings.
          </p>
          <p className="privacy-contact">
            Data requests and questions: <b>[add your team's contact address]</b>
          </p>
        </section>

        <p className="privacy-updated">Last updated 13 September 2026.</p>
      </div>
    </div>
  );
}
