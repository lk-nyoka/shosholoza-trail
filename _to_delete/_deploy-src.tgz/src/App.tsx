import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/layout/Layout";
import Home        from "./pages/Home";
import Journey     from "./pages/Journey";
import Ride        from "./pages/Ride";
import Destinations from "./pages/Destinations";
import Stories     from "./pages/Stories";
import AIGuide     from "./pages/AIGuide";
import Plan        from "./pages/Plan";
import LiveJourney from "./pages/LiveJourney";
import Credits     from "./pages/Credits";
import Privacy     from "./pages/Privacy";
import Help        from "./pages/Help";
import Start       from "./pages/Start";
import Trip        from "./pages/Trip";
import Song        from "./pages/Song";
import Operator    from "./pages/Operator";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route index            element={<Home />}         />
          <Route path="journey"   element={<Journey />}      />
          <Route path="ride"      element={<Ride />}         />
          <Route path="destinations" element={<Destinations />} />
          <Route path="stories"   element={<Stories />}      />
          <Route path="ai"        element={<AIGuide />}      />
          <Route path="plan"      element={<Plan />}         />
          <Route path="app"       element={<LiveJourney />}  />
          <Route path="credits"   element={<Credits />}      />
          <Route path="privacy"   element={<Privacy />}      />
          <Route path="help"      element={<Help />}         />
          <Route path="start"     element={<Start />}        />
          <Route path="trip"      element={<Trip />}         />
          <Route path="shosholoza" element={<Song />}        />
          <Route path="operator"  element={<Operator />}     />
          {/* legacy hash route → new path */}
          <Route path="*"         element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
